/* TubeEQ v2 popup */
const $ = s => document.querySelector(s);
const DEFAULTS = JSON.parse(JSON.stringify(TQ.DEFAULTS));
let fxDirty = false, savedFx = null;
let state = JSON.parse(JSON.stringify(DEFAULTS));
let rt = { src: 'manual', channelName: '', remembered: false };
let status = 'no-video';
let vizPort = null;

const t = k => TQ.t(state.lang, k);
const fmtDb = db => (db > 0 ? '+' : '') + Number(db).toFixed(1);

/* version hien thi lay tu manifest */
try { $('#ver').textContent = 'v' + chrome.runtime.getManifest().version; } catch (e) {}

/* ---------- build vertical band sliders ---------- */
const bandsEl = $('#bands');
TQ.BANDS.forEach((b, i) => {
  const d = document.createElement('div');
  d.className = 'band';
  d.innerHTML =
    '<span class="bval" id="bv' + i + '">+0.0</span>' +
    '<input type="range" id="bs' + i + '" min="-12" max="12" step="0.5" value="0" title="">' +
    '<span class="blabel" id="bl' + i + '"></span>';
  bandsEl.appendChild(d);
  d.querySelector('input').addEventListener('input', e => {
    state.gains[i] = parseFloat(e.target.value);
    state.preset = 'custom';
    render(false);
    push();
  });
});

/* ---------- build fx sliders ---------- */
const fxEl = $('#fx');
TQ.FX.forEach(fx => {
  const d = document.createElement('div');
  d.className = 'fx';
  d.innerHTML =
    '<div class="fx-head"><span class="fxlabel" id="fxl_' + fx.id + '"></span>' +
    '<span class="val" id="fxv_' + fx.id + '"></span></div>' +
    '<input type="range" id="fxs_' + fx.id + '" min="0" max="10" step="1" value="' + fx.def + '" title="">';
  fxEl.appendChild(d);
  d.querySelector('input').addEventListener('input', e => {
    state.effects[fx.id] = parseInt(e.target.value, 10);
    fxDirty = true;
    render(false);
    pushLive();
  });
});

/* ---------- preset menu (custom dropdown, theo theme) ---------- */
function presetItems() {
  const items = [];
  TQ.PRESET_GROUPS.forEach(gr => {
    items.push({ group: t('groups')[gr.id] });
    gr.keys.forEach(k => items.push({ k, label: t('names')[k] }));
  });
  items.push({ k: 'custom', label: t('custom') });
  const mine = Object.keys(state.customPresets || {});
  if (mine.length) {
    items.push({ group: t('myPresets') });
    mine.sort().forEach(name => items.push({ k: 'user:' + name, label: name }));
  }
  return items;
}
function buildPresetOptions() {
  const menu = $('#presetMenu');
  menu.innerHTML = '';
  presetItems().forEach(it => {
    const d = document.createElement('div');
    if (it.group) { d.className = 'pgroup'; d.textContent = it.group; }
    else {
      d.className = 'pitem'; d.dataset.k = it.k;
      const dot = document.createElement('span'); dot.className = 'dot';
      const lb = document.createElement('span'); lb.textContent = it.label;
      d.appendChild(dot); d.appendChild(lb);
      d.addEventListener('click', e => { e.stopPropagation(); choosePreset(it.k); });
    }
    menu.appendChild(d);
  });
  syncPresetMenu();
}
function currentPresetKey() {
  const upn = userPresetName();
  return TQ.PRESETS[state.preset] ? state.preset
    : (upn && state.customPresets[upn] ? state.preset : 'custom');
}
function presetLabelFor(k) {
  if (k === 'custom') return t('custom');
  if (k.indexOf('user:') === 0) return k.slice(5);
  return (t('names') && t('names')[k]) || k;
}
function syncPresetMenu() {
  const k = currentPresetKey();
  $('#presetLabel').textContent = presetLabelFor(k);
  document.querySelectorAll('#presetMenu .pitem').forEach(el => {
    el.classList.toggle('sel', el.dataset.k === k);
  });
}
function choosePreset(k) {
  closePresetMenu();
  if (k === 'custom') return;
  if (k.indexOf('user:') === 0) { if (applyUserPreset(k.slice(5))) { savedFx = Object.assign({}, state.effects); fxDirty = false; render(false); push(); } }
  else if (TQ.PRESETS[k]) { state.gains = [...TQ.PRESETS[k].g]; state.effects = Object.assign({}, TQ.DEFAULTS.effects, TQ.PRESETS[k].fx || {}); state.preset = k; savedFx = Object.assign({}, state.effects); fxDirty = false; render(false); push(); }
}
function closePresetMenu() { $('#presetMenu').classList.add('hidden'); }

/* user preset helpers */
function userPresetName() {
  return state.preset && state.preset.indexOf('user:') === 0 ? state.preset.slice(5) : null;
}
function applyUserPreset(name) {
  const p = (state.customPresets || {})[name];
  if (!p || !Array.isArray(p.g) || p.g.length !== 10) return false;
  state.gains = [...p.g];
  state.effects = Object.assign({}, TQ.DEFAULTS.effects, p.fx || {});
  state.preset = 'user:' + name;
  return true;
}

/* ---------- i18n static ---------- */
function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  $('#nonstopLabel').title = t('nonstopDesc');
  syncLangMenu();
  $('#importCode').placeholder = t('importPh');
  $('#savePreset').title = t('saveTip');
  $('#saveName').placeholder = t('saveNamePh');
  $('#hint').textContent = t('hint');
  TQ.BANDS.forEach((b, i) => {
    $('#bl' + i).textContent = b.label;
  });
  buildPresetOptions();
}

/* ---------- render ---------- */
function render(full = true) {
  if (full) applyI18n();
  TQ.BANDS.forEach((_, i) => {
    $('#bs' + i).value = state.gains[i];
    $('#bv' + i).textContent = fmtDb(state.gains[i]);
    const tip = t('bandTags')[i] + ' - ' + (t('bandDesc')[i] || '');
    $('#bl' + i).title = tip;
    $('#bs' + i).title = tip;
  });
  TQ.FX.forEach(fx => {
    $('#fxs_' + fx.id).value = state.effects[fx.id];
    $('#fxv_' + fx.id).textContent = state.effects[fx.id] + '/10';
    $('#fxl_' + fx.id).textContent = t('fxNames')[fx.id];
    const tip = t('fxDesc')[fx.id] || '';
    $('#fxl_' + fx.id).title = tip;
    $('#fxs_' + fx.id).title = tip;
  });
  syncPresetMenu();
  $('#vol').value = state.volume;
  $('#volval').textContent = state.volume + '%';
  $('#smart').checked = state.smart;
  $('#nonstop').checked = !!state.nonstop;
  const p = $('#power');
  p.classList.toggle('on', state.enabled);
  document.body.classList.toggle('disabled', !state.enabled);
  const ab = $('#ab');
  ab.classList.toggle('active', state.ab);
  ab.title = t('abHint') + (state.ab ? ' - ' + t('abOn') : '');

  // status line
  const dot = $('#sdot'), txt = $('#stext');
  dot.className = 'sdot ' + (status === 'ready' ? (state.enabled ? 'ok' : 'warn') : status === 'needs-reload' ? 'warn' : 'bad');
  let s = status === 'ready' ? (state.enabled ? t('statusOk') : t('statusOff'))
        : status === 'needs-reload' ? t('statusReload') : t('statusNoVideo');
  const pname = TQ.PRESETS[state.preset] ? t('names')[state.preset]
    : (userPresetName() || t('custom'));
  const via = (state.preset === 'custom' && !userPresetName()) ? '' : ' · ' + pname + ' (' + t('via' + cap(rt.src || 'manual')) + ')';
  txt.textContent = s + (status === 'ready' && state.enabled ? via : '');

  // remember button
  const rb = $('#remember');
  if (rt.channelName) {
    rb.disabled = false;
    rb.textContent = (rt.remembered ? t('forget') : t('remember')) + ' - ' + rt.channelName;
    rb.classList.toggle('remembered', rt.remembered);
  } else {
    rb.disabled = true;
    rb.textContent = t('remember') + '…';
  }
}
function cap(s) { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); }
// diet gains la tu ban cu (5 band) - neu khong slider se nhan undefined
function fixGains() {
  if (!Array.isArray(state.gains) || state.gains.length !== 10) state.gains = [...DEFAULTS.gains];
}

/* ---------- comms ---------- */
function isYouTubeTab(tab) {
  return tab && tab.url && /^https:\/\/([a-z0-9-]+\.)?youtube\.com\//.test(tab.url);
}
async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}
let pushTimer = null;
async function pushLive() {
  try {
    const tab = await activeTab();
    if (isYouTubeTab(tab)) await chrome.tabs.sendMessage(tab.id, { type: 'tq-state', state });
  } catch (e) {}
}
async function pushSend() {
  try {
    const toSave = fxDirty && savedFx ? Object.assign({}, state, { effects: Object.assign({}, savedFx) }) : state;
    await chrome.storage.sync.set({ tqV2: toSave });
  } catch (e) {}
  await pushLive();
}
async function push(now) {
  clearTimeout(pushTimer);
  if (now) { await pushSend(); return; }
  pushTimer = setTimeout(pushSend, 60);
}
function showDiag(txt, showRetry) {
  const h = $('#hint');
  h.textContent = txt;
  h.classList.remove('hidden');
  const rb = $('#retryBtn');
  rb.textContent = t('retry');
  rb.classList.toggle('hidden', !showRetry);
}
$('#retryBtn').addEventListener('click', () => { $('#retryBtn').classList.add('hidden'); pull(); });
async function pull() {
  try {
    const tab = await activeTab();
    if (!isYouTubeTab(tab)) { status = 'no-video'; $('#hint').textContent = t('hint'); $('#hint').classList.remove('hidden'); render(false); return; }
    $('#hint').classList.add('hidden');
    const r = await Promise.race([
      chrome.tabs.sendMessage(tab.id, { type: 'tq-get' }),
      new Promise((_, rej) => setTimeout(() => rej(new Error('timeout: tab không trả lời sau 3s')), 3000)),
    ]);
    if (r && r.state) {
      const keepLang = state.lang;
      state = Object.assign(JSON.parse(JSON.stringify(DEFAULTS)), r.state);
      state.lang = r.state.lang || keepLang;
      fixGains();
      rt = r.rt || rt; status = r.status || 'ready';
      render(false);
      if (r.lastHookError) showDiag('Lỗi bắt video: ' + r.lastHookError);
      else if (status === 'error') showDiag('Lỗi nội bộ content script, chụp màn hình gửi tôi nhé.');
    }
  } catch (e) {
    status = 'needs-reload'; render(false);
    showDiag('Không liên lạc được với tab. Hãy F5 tab YouTube rồi bấm Thử lại.', true);
  }
}

/* ---------- events ---------- */
$('#presetBtn').addEventListener('click', e => {
  e.stopPropagation();
  closeLangMenu();
  $('#presetMenu').classList.toggle('hidden');
});
document.addEventListener('click', () => { closePresetMenu(); closeLangMenu(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closePresetMenu(); closeLangMenu(); } });
$('#power').addEventListener('click', () => { state.enabled = !state.enabled; render(false); push(); });
$('#ab').addEventListener('click', () => { state.ab = !state.ab; render(false); push(); });
$('#reset').addEventListener('click', () => {
  const lang = state.lang;
  state = JSON.parse(JSON.stringify(DEFAULTS)); state.lang = lang;
  savedFx = Object.assign({}, state.effects); fxDirty = false;
  render(false); push();
});
$('#vol').addEventListener('input', e => {
  state.volume = parseInt(e.target.value, 10);
  $('#volval').textContent = state.volume + '%';
  push();
});
$('#smart').addEventListener('change', e => { state.smart = e.target.checked; push(); });
$('#nonstop').addEventListener('change', e => { state.nonstop = e.target.checked; push(); });
/* ---------- language selector (custom dropdown) ---------- */
TQ.LANGS.forEach(([code, name]) => {
  const d = document.createElement('div');
  d.className = 'pitem'; d.dataset.k = code;
  const dot = document.createElement('span'); dot.className = 'dot';
  const lb = document.createElement('span'); lb.textContent = name;
  d.appendChild(dot); d.appendChild(lb);
  d.addEventListener('click', e => {
    e.stopPropagation();
    $('#langMenu').classList.add('hidden');
    if (state.lang !== code) { state.lang = code; render(true); push(); }
  });
  $('#langMenu').appendChild(d);
});
function syncLangMenu() {
  const cur = TQ.LANGS.find(([c]) => c === state.lang);
  $('#langLabel').textContent = cur ? cur[1] : state.lang;
  document.querySelectorAll('#langMenu .pitem').forEach(el => {
    el.classList.toggle('sel', el.dataset.k === state.lang);
  });
}
$('#langBtn').addEventListener('click', e => {
  e.stopPropagation();
  closePresetMenu();
  $('#langMenu').classList.toggle('hidden');
});
function closeLangMenu() { $('#langMenu').classList.add('hidden'); }
$('#remember').addEventListener('click', async () => {
  try {
    const tab = await activeTab();
    if (!isYouTubeTab(tab)) return;
    const r = await chrome.tabs.sendMessage(tab.id, { type: 'tq-remember', forget: rt.remembered });
    if (r) { rt.remembered = r.remembered; render(false); }
  } catch (e) {}
});
$('#share').addEventListener('click', async () => {
  const code = TQ.encodePreset(state.gains, state.effects);
  try { await navigator.clipboard.writeText(code); } catch (e) {}
  const toast = $('#toast');
  toast.textContent = t('copied') + ' ' + code;
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), 2500);
});
$('#importToggle').addEventListener('click', () => $('#importRow').classList.toggle('hidden'));
function toastOk(msg) {
  const toast = $('#toast');
  toast.textContent = msg;
  toast.classList.remove('err');
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), 2500);
}
function toastErr(msg) {
  const toast = $('#toast');
  toast.textContent = msg;
  toast.classList.add('err');
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), 2500);
}
/* ---------- full backup / restore ---------- */
const numArr10 = a => Array.isArray(a) && a.length === 10 && a.every(n => Number.isFinite(n));
function sanitizeRestored(s) {
  const d = JSON.parse(JSON.stringify(DEFAULTS));
  if (!s || typeof s !== 'object') return d;
  const out = Object.assign(d, {});
  if (numArr10(s.gains)) out.gains = s.gains.map(n => Math.max(-12, Math.min(12, n)));
  if (s.effects && typeof s.effects === 'object') {
    for (const k of Object.keys(d.effects))
      if (Number.isFinite(s.effects[k])) out.effects[k] = Math.max(0, Math.min(10, s.effects[k]));
  }
  if (Number.isFinite(s.volume)) out.volume = Math.max(0, Math.min(200, s.volume));
  if (typeof s.preset === 'string') out.preset = s.preset;
  if (typeof s.smart === 'boolean') out.smart = s.smart;
  if (typeof s.nonstop === 'boolean') out.nonstop = s.nonstop;
  if (typeof s.lang === 'string') out.lang = s.lang;
  if (typeof s.enabled === 'boolean') out.enabled = s.enabled;
  if (s.customPresets && typeof s.customPresets === 'object') {
    out.customPresets = {};
    for (const [name, p] of Object.entries(s.customPresets)) {
      if (!p || typeof p !== 'object' || !numArr10(p.g || p.gains)) continue;
      const g = (p.g || p.gains).map(n => Math.max(-12, Math.min(12, n)));
      const fx = {};
      const srcFx = p.fx || p.effects || {};
      for (const k of Object.keys(d.effects))
        if (Number.isFinite(srcFx[k])) fx[k] = Math.max(0, Math.min(10, srcFx[k]));
      out.customPresets[String(name).slice(0, 24)] = { g, fx };
    }
  }
  if (s.perChannel && typeof s.perChannel === 'object') {
    out.perChannel = {};
    for (const [ch, v] of Object.entries(s.perChannel)) {
      if (!v || typeof v !== 'object' || !numArr10(v.gains)) continue;
      out.perChannel[ch] = { gains: v.gains.map(n => Math.max(-12, Math.min(12, n))), preset: typeof v.preset === 'string' ? v.preset : 'custom', name: typeof v.name === 'string' ? v.name.slice(0, 24) : '' };
    }
  }
  return out;
}
$('#backup').addEventListener('click', () => {
  const data = { app: 'TubeEQ', kind: 'full-backup', v: 1, exportedAt: new Date().toISOString(), state };
  const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
  const a = document.createElement('a');
  const d = new Date(), pad = n => String(n).padStart(2, '0');
  a.href = URL.createObjectURL(blob);
  a.download = `tubeeq-backup-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  toastOk(t('backupDone'));
});
$('#restore').addEventListener('click', () => $('#restoreFile').click());
$('#weblink').addEventListener('click', () => { try { chrome.tabs.create({ url: TQ.WELCOME_URL }); } catch (e) {} });
$('#restoreFile').addEventListener('change', async e => {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f) return;
  try {
    const data = JSON.parse(await f.text());
    if (!data || data.app !== 'TubeEQ' || !data.state) throw new Error('bad file');
    state = sanitizeRestored(data.state);
    fixGains();
    render(false); push(true);
    toastOk(t('restoreDone'));
  } catch (err) { toastErr(t('restoreFail')); }
});
function doImport() {
  const r = TQ.decodePreset($('#importCode').value);
  if (!r) {
    const inp = $('#importCode');
    inp.style.borderColor = '#ff3b5c';
    setTimeout(() => { inp.style.borderColor = ''; }, 1200);
    const toast = $('#toast');
    toast.textContent = t('invalidCode');
    toast.classList.add('err');
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 2500);
    return;
  }
  state.gains = r.gains;
  if (r.fx) state.effects = Object.assign({}, TQ.DEFAULTS.effects, r.fx);
  else state.effects = Object.assign({}, TQ.DEFAULTS.effects);
  savedFx = Object.assign({}, state.effects); fxDirty = false;
  state.preset = 'custom';
  state.smart = false; // nhap tay thang automation: tat Smart EQ de preset nhap khong bi de lai
  render(false); push(true); $('#importRow').classList.add('hidden');
  const toast = $('#toast');
  toast.textContent = t('imported');
  toast.classList.remove('err');
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), 2500);
}
$('#importApply').addEventListener('click', doImport);
$('#importCode').addEventListener('keydown', e => { if (e.key === 'Enter') doImport(); });

/* ---------- save / delete user presets ---------- */
$('#savePreset').addEventListener('click', () => {
  const row = $('#saveRow');
  row.classList.toggle('hidden');
  const upn = userPresetName();
  $('#saveName').value = upn || '';
  $('#saveDelete').classList.toggle('hidden', !upn);
  if (!row.classList.contains('hidden')) $('#saveName').focus();
});
$('#saveApply').addEventListener('click', () => {
  const name = $('#saveName').value.trim().slice(0, 24);
  if (!name) { $('#saveName').focus(); return; }
  state.customPresets = state.customPresets || {};
  state.customPresets[name] = { g: [...state.gains], fx: Object.assign({}, state.effects) };
  state.preset = 'user:' + name;
  savedFx = Object.assign({}, state.effects); fxDirty = false;
  $('#saveRow').classList.add('hidden');
  const toast = $('#toast');
  toast.textContent = t('presetSaved') + ' ' + name;
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), 2500);
  render(true); push();
});
$('#saveDelete').addEventListener('click', () => {
  const upn = userPresetName();
  if (!upn) return;
  delete state.customPresets[upn];
  state.preset = 'custom';
  $('#saveRow').classList.add('hidden');
  render(true); push();
});

/* ---------- visualizer ---------- */
const viz = $('#viz'), vctx = viz.getContext('2d');
function drawViz(bins, clip) {
  const W = viz.width, H = viz.height;
  vctx.clearRect(0, 0, W, H);
  const n = bins.length, bw = W / n;
  for (let i = 0; i < n; i++) {
    const h = (bins[i] / 255) * H;
    vctx.fillStyle = '#ff3b5c';
    vctx.fillRect(i * bw + 1, H - h, bw - 2, h);
  }
  const c = $('#clip');
  c.classList.toggle('hot', !!clip);
}
async function startViz() {
  try {
    const tab = await activeTab();
    if (!isYouTubeTab(tab)) return;
    vizPort = chrome.tabs.connect(tab.id, { name: 'tq-viz' });
    vizPort.onMessage.addListener(m => drawViz(m.bins, m.clip));
    vizPort.onDisconnect.addListener(() => { void chrome.runtime.lastError; vizPort = null; });
  } catch (e) {}
}


/* ---------- tabs + community ---------- */
const TQ_API = 'https://tubeeq-api-dongvan2.vercel.app';
let comLoaded = false;
function switchTab(which) {
  $('#tabBtnEQ').classList.toggle('on', which === 'EQ');
  $('#tabBtnCom').classList.toggle('on', which === 'COM');
  $('#tabEQ').classList.toggle('hidden', which !== 'EQ');
  $('#tabCom').classList.toggle('hidden', which !== 'COM');
  if (which === 'COM' && !comLoaded) loadCommunity();
}
async function loadCommunity() {
  const box = $('#comList');
  try {
    const r = await fetch(TQ_API + '/api/presets');
    const j = await r.json();
    box.innerHTML = '';
    (j.presets || []).slice(0, 10).forEach(p => {
      const d = document.createElement('div');
      d.className = 'comitem';
      d.innerHTML = '<div class="cname"><b></b><span></span></div><span class="creact"></span><button class="chip capply"></button>';
      d.querySelector('b').textContent = p.name;
      d.querySelector('.cname span').textContent = p.author + ' · ' + (p.tags || []).join(', ');
      d.querySelector('.creact').textContent = '❤️ ' + (p.reactions || 0);
      const ab = d.querySelector('.capply');
      ab.textContent = t('apply');
      ab.addEventListener('click', () => {
        const dec = TQ.decodePreset(p.code);
        if (!dec) return;
        state.gains = dec.gains;
        if (dec.fx) state.effects = Object.assign({}, TQ.DEFAULTS.effects, dec.fx);
        else state.effects = Object.assign({}, TQ.DEFAULTS.effects);
        state.preset = 'community:' + p.name;
        savedFx = Object.assign({}, state.effects); fxDirty = false;
        render(false); push(true);
        switchTab('EQ');
      });
      box.appendChild(d);
    });
    if (!(j.presets || []).length) box.innerHTML = '<p class="hint">' + t('loading') + '</p>';
    comLoaded = true;
  } catch (e) { box.innerHTML = '<p class="hint">offline</p>'; }
}
/* ---------- version check ---------- */
async function checkUpdate() {
  try {
    const r = await fetch(TQ_API + '/api/version');
    const j = await r.json();
    const cur = chrome.runtime.getManifest().version;
    if (j.version && j.version !== cur) {
      const v = $('#ver');
      v.innerHTML = 'v' + cur + ' <a href="' + j.url + '" target="_blank" style="color:#ff3b5c;font-weight:700">● ' + t('updateAvail') + '</a>';
    }
  } catch (e) {}
}
$('#tabBtnEQ').addEventListener('click', () => switchTab('EQ'));
$('#tabBtnCom').addEventListener('click', () => switchTab('COM'));

/* ---------- boot ---------- */

(async () => {
  try {
    const r = await chrome.storage.sync.get({ tqV2: null });
    if (r.tqV2) {
      const fx = r.tqV2.effects;
      state = Object.assign(JSON.parse(JSON.stringify(DEFAULTS)), r.tqV2);
      state.effects = Object.assign({}, DEFAULTS.effects, fx || {}); // va cho state cu (v2.0)
      fixGains();
    }
  } catch (e) {}
  savedFx = Object.assign({}, state.effects);
  render(true);
  checkUpdate();
  await pull();
  startViz();
  setInterval(pull, 2500); // dong bo khi chuyen video (auto preset)
})();
