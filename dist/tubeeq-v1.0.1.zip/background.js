/* TubeEQ background service worker, chi mo trang chao khi cai moi */
importScripts('shared.js');

chrome.runtime.onInstalled.addListener(details => {
  if (details.reason === 'install' && TQ.WELCOME_URL) {
    chrome.tabs.create({ url: TQ.WELCOME_URL });
  }
});
